import 'package:flutter/material.dart';
import '../data/categories_data.dart';
import '../models/category_model.dart';
import '../widgets/category_selector.dart';
import '../widgets/dynamic_form_fields.dart';

class AddProductScreen extends StatefulWidget {
  const AddProductScreen({super.key});

  @override
  State<AddProductScreen> createState() => _AddProductScreenState();
}

class _AddProductScreenState extends State<AddProductScreen> {
  final _formKey = GlobalKey<FormState>();

  Category? _selectedParent;
  Category? _selectedChild;
  final Map<String, dynamic> _formValues = {};

  // Combined fields: parent fields + child fields (child overrides parent if same name)
  List<CategoryField> get _activeFields {
    if (_selectedParent == null) return [];
    final parentFields = _selectedParent!.fields;
    final childFields = _selectedChild?.fields ?? [];

    // Merge: child fields come first, then parent fields not already covered by child
    final childFieldNames = childFields.map((f) => f.name).toSet();
    final mergedParentFields = parentFields.where((f) => !childFieldNames.contains(f.name)).toList();

    return [...childFields, ...mergedParentFields];
  }

  void _onParentSelected(Category cat) {
    setState(() {
      _selectedParent = cat;
      _selectedChild = null;
      _formValues.clear();
    });
  }

  void _onChildSelected(Category? cat) {
    setState(() {
      _selectedChild = cat;
      // Clear child-specific field values when child changes
      final oldChildFields = _selectedChild?.fields.map((f) => f.name).toSet() ?? {};
      for (final key in oldChildFields) {
        _formValues.remove(key);
      }
    });
  }

  void _onFieldChanged(String name, dynamic value) {
    setState(() {
      _formValues[name] = value;
    });
  }

  void _submit() {
    if (_formKey.currentState?.validate() ?? false) {
      final result = {
        'categoryId': _selectedChild?.id ?? _selectedParent?.id,
        'categoryName': _selectedChild?.name ?? _selectedParent?.name,
        ..._formValues,
      };
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✅ Yuborildi: ${result.toString()}'),
          backgroundColor: const Color(0xFF6C63FF),
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF121218),
      appBar: AppBar(
        backgroundColor: const Color(0xFF1A1A28),
        elevation: 0,
        title: const Text(
          'E\'lon qo\'shish',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w600,
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: const Color(0xFF2D2D3F)),
        ),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Category selector
              _buildCard(
                child: CategorySelector(
                  categories: appCategories,
                  selectedParent: _selectedParent,
                  selectedChild: _selectedChild,
                  onParentSelected: _onParentSelected,
                  onChildSelected: _onChildSelected,
                ),
              ),

              // Dynamic fields
              if (_selectedParent != null) ...[
                const SizedBox(height: 16),
                _buildCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Selected category breadcrumb
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFF6C63FF).withOpacity(0.15),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.folder_open_rounded, color: Color(0xFF6C63FF), size: 14),
                            const SizedBox(width: 6),
                            Text(
                              _selectedParent!.name +
                                  (_selectedChild != null ? ' › ${_selectedChild!.name}' : ''),
                              style: const TextStyle(
                                color: Color(0xFF9D96FF),
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),

                      if (_activeFields.isEmpty)
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            child: Text(
                              _selectedParent!.hasChildren && _selectedChild == null
                                  ? 'Ichki kategoriyani tanlang'
                                  : 'Bu kategoriya uchun qo\'shimcha maydonlar yo\'q',
                              style: TextStyle(color: Colors.grey[600], fontSize: 13),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        )
                      else
                        DynamicFormFields(
                          fields: _activeFields,
                          formValues: _formValues,
                          onChanged: _onFieldChanged,
                        ),
                    ],
                  ),
                ),

                // Common fields: title, price, description
                const SizedBox(height: 16),
                _buildCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildCommonTextField(
                        label: 'Sarlavha',
                        hint: 'Masalan: iPhone 15 Pro Max 256GB',
                        required: true,
                        onChanged: (v) => _onFieldChanged('title', v),
                      ),
                      const SizedBox(height: 16),
                      _buildPriceField(),
                      const SizedBox(height: 16),
                      _buildCommonTextField(
                        label: 'Tavsif',
                        hint: 'Mahsulot haqida batafsil yozing...',
                        maxLines: 4,
                        onChanged: (v) => _onFieldChanged('description', v),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: ElevatedButton(
                    onPressed: _submit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF6C63FF),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                      elevation: 0,
                    ),
                    child: const Text(
                      'E\'lon joylash',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
                const SizedBox(height: 32),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCard({required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF16161F),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF2D2D3F)),
      ),
      child: child,
    );
  }

  Widget _buildCommonTextField({
    required String label,
    required String hint,
    int maxLines = 1,
    bool required = false,
    required void Function(String) onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              label,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Color(0xFFE0E0E0),
              ),
            ),
            if (required)
              const Text(' *', style: TextStyle(color: Color(0xFFFF5252), fontSize: 14)),
          ],
        ),
        const SizedBox(height: 8),
        TextFormField(
          maxLines: maxLines,
          style: const TextStyle(color: Color(0xFFE0E0E0), fontSize: 14),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: Colors.grey[600], fontSize: 14),
            filled: true,
            fillColor: const Color(0xFF1E1E2E),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF2D2D3F)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF2D2D3F)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF6C63FF), width: 1.5),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
          onChanged: onChanged,
          validator: required
              ? (v) => (v == null || v.isEmpty) ? '$label majburiy' : null
              : null,
        ),
      ],
    );
  }

  Widget _buildPriceField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Text(
              'Narx',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Color(0xFFE0E0E0)),
            ),
            Text(' *', style: TextStyle(color: Color(0xFFFF5252), fontSize: 14)),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            // Currency selector
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFF1E1E2E),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFF2D2D3F)),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: _formValues['currency'] as String? ?? 'UZS',
                  dropdownColor: const Color(0xFF1E1E2E),
                  icon: const SizedBox.shrink(),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  borderRadius: BorderRadius.circular(12),
                  items: ['UZS', 'USD'].map((c) => DropdownMenuItem(
                    value: c,
                    child: Text(c, style: const TextStyle(color: Color(0xFF9D96FF), fontSize: 13, fontWeight: FontWeight.w600)),
                  )).toList(),
                  onChanged: (v) => setState(() => _formValues['currency'] = v),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: TextFormField(
                keyboardType: TextInputType.number,
                style: const TextStyle(color: Color(0xFFE0E0E0), fontSize: 14),
                decoration: InputDecoration(
                  hintText: '0.00',
                  hintStyle: TextStyle(color: Colors.grey[600], fontSize: 14),
                  filled: true,
                  fillColor: const Color(0xFF1E1E2E),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xFF2D2D3F)),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xFF2D2D3F)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: const BorderSide(color: Color(0xFF6C63FF), width: 1.5),
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                ),
                onChanged: (v) => _onFieldChanged('price', v),
                validator: (v) => (v == null || v.isEmpty) ? 'Narx majburiy' : null,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
