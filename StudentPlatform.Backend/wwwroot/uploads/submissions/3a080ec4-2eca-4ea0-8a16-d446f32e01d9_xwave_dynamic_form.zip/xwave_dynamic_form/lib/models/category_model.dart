class CategoryField {
  final String name;
  final String type; // number, select, text, multi-select
  final String label;
  final List<String>? options;
  final bool required;
  final num? min;
  final num? max;

  const CategoryField({
    required this.name,
    required this.type,
    required this.label,
    this.options,
    this.required = false,
    this.min,
    this.max,
  });

  factory CategoryField.fromJson(Map<String, dynamic> json) {
    return CategoryField(
      name: json['name'] as String,
      type: json['type'] as String,
      label: json['label'] as String,
      options: (json['options'] as List<dynamic>?)?.map((e) => e.toString()).toList(),
      required: json['required'] as bool? ?? false,
      min: json['min'] as num?,
      max: json['max'] as num?,
    );
  }
}

class Category {
  final int id;
  final String name;
  final int? parentId;
  final List<Category>? children;
  final List<CategoryField> fields;

  const Category({
    required this.id,
    required this.name,
    this.parentId,
    this.children,
    required this.fields,
  });

  factory Category.fromJson(Map<String, dynamic> json) {
    return Category(
      id: json['id'] as int,
      name: json['name'] as String,
      parentId: json['parentId'] as int?,
      children: (json['children'] as List<dynamic>?)
          ?.map((e) => Category.fromJson(e as Map<String, dynamic>))
          .toList(),
      fields: (json['fields'] as List<dynamic>)
          .map((e) => CategoryField.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }

  bool get hasChildren => children != null && children!.isNotEmpty;
}
