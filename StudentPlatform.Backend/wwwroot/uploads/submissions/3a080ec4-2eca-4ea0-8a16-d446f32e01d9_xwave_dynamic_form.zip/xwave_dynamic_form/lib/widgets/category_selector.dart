import 'package:flutter/material.dart';
import '../models/category_model.dart';

class CategorySelector extends StatelessWidget {
  final List<Category> categories;
  final Category? selectedParent;
  final Category? selectedChild;
  final void Function(Category) onParentSelected;
  final void Function(Category?) onChildSelected;

  const CategorySelector({
    super.key,
    required this.categories,
    required this.selectedParent,
    required this.selectedChild,
    required this.onParentSelected,
    required this.onChildSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionLabel('Kategoriya'),
        _buildParentGrid(),
        if (selectedParent != null && selectedParent!.hasChildren) ...[
          const SizedBox(height: 16),
          _buildSectionLabel('Ichki kategoriya'),
          _buildChildList(),
        ],
      ],
    );
  }

  Widget _buildSectionLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          color: Color(0xFFE0E0E0),
        ),
      ),
    );
  }

  Widget _buildParentGrid() {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        childAspectRatio: 2.2,
      ),
      itemCount: categories.length,
      itemBuilder: (context, index) {
        final cat = categories[index];
        final isSelected = selectedParent?.id == cat.id;
        return GestureDetector(
          onTap: () {
            onParentSelected(cat);
            onChildSelected(null);
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            decoration: BoxDecoration(
              color: isSelected ? const Color(0xFF6C63FF) : const Color(0xFF1E1E2E),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: isSelected ? const Color(0xFF6C63FF) : const Color(0xFF2D2D3F),
              ),
            ),
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Text(
              _categoryIcon(cat.id) + ' ' + cat.name,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: isSelected ? Colors.white : const Color(0xFFAAAAAA),
                fontSize: 11,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        );
      },
    );
  }

  Widget _buildChildList() {
    final children = selectedParent!.children!;
    return Column(
      children: children.map((child) {
        final isSelected = selectedChild?.id == child.id;
        return GestureDetector(
          onTap: () => onChildSelected(isSelected ? null : child),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: isSelected ? const Color(0xFF6C63FF).withOpacity(0.15) : const Color(0xFF1E1E2E),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isSelected ? const Color(0xFF6C63FF) : const Color(0xFF2D2D3F),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: isSelected ? const Color(0xFF6C63FF) : const Color(0xFF444455),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    child.name,
                    style: TextStyle(
                      color: isSelected ? const Color(0xFF9D96FF) : const Color(0xFFCCCCCC),
                      fontSize: 13,
                      fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                    ),
                  ),
                ),
                if (isSelected)
                  const Icon(Icons.check_circle_rounded, color: Color(0xFF6C63FF), size: 18),
              ],
            ),
          ),
        );
      }).toList(),
    );
  }

  String _categoryIcon(int id) {
    return switch (id) {
      10 => '🚗',
      15 => '📱',
      22 => '🏠',
      27 => '💼',
      34 => '🛋️',
      40 => '👗',
      45 => '🔧',
      51 => '🐾',
      _ => '📦',
    };
  }
}
