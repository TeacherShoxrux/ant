import 'package:flutter/material.dart';
import '../models/category_model.dart';

class DynamicFormFields extends StatefulWidget {
  final List<CategoryField> fields;
  final Map<String, dynamic> formValues;
  final void Function(String name, dynamic value) onChanged;

  const DynamicFormFields({
    super.key,
    required this.fields,
    required this.formValues,
    required this.onChanged,
  });

  @override
  State<DynamicFormFields> createState() => _DynamicFormFieldsState();
}

class _DynamicFormFieldsState extends State<DynamicFormFields> {
  @override
  Widget build(BuildContext context) {
    if (widget.fields.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: widget.fields.map((field) => _buildField(field)).toList(),
    );
  }

  Widget _buildField(CategoryField field) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: switch (field.type) {
        'select' => _buildSelect(field),
        'multi-select' => _buildMultiSelect(field),
        'number' => _buildNumber(field),
        'text' => _buildText(field),
        _ => _buildText(field),
      },
    );
  }

  Widget _buildLabel(CategoryField field) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Text(
            field.label,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w500,
              color: Color(0xFFE0E0E0),
            ),
          ),
          if (field.required)
            const Text(
              ' *',
              style: TextStyle(color: Color(0xFFFF5252), fontSize: 14),
            ),
        ],
      ),
    );
  }

  Widget _buildSelect(CategoryField field) {
    final currentValue = widget.formValues[field.name] as String?;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLabel(field),
        Container(
          decoration: BoxDecoration(
            color: const Color(0xFF1E1E2E),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF2D2D3F)),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: currentValue,
              hint: Text(
                'Tanlang',
                style: TextStyle(color: Colors.grey[600], fontSize: 14),
              ),
              isExpanded: true,
              dropdownColor: const Color(0xFF1E1E2E),
              icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Color(0xFF6C63FF)),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              borderRadius: BorderRadius.circular(12),
              items: field.options!
                  .map((opt) => DropdownMenuItem(
                        value: opt,
                        child: Text(
                          opt,
                          style: const TextStyle(color: Color(0xFFE0E0E0), fontSize: 14),
                        ),
                      ))
                  .toList(),
              onChanged: (val) => widget.onChanged(field.name, val),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMultiSelect(CategoryField field) {
    final selected = (widget.formValues[field.name] as List<String>?) ?? [];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLabel(field),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: field.options!.map((opt) {
            final isSelected = selected.contains(opt);
            return GestureDetector(
              onTap: () {
                final newList = List<String>.from(selected);
                if (isSelected) {
                  newList.remove(opt);
                } else {
                  newList.add(opt);
                }
                widget.onChanged(field.name, newList);
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: isSelected ? const Color(0xFF6C63FF) : const Color(0xFF1E1E2E),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: isSelected ? const Color(0xFF6C63FF) : const Color(0xFF2D2D3F),
                  ),
                ),
                child: Text(
                  opt,
                  style: TextStyle(
                    color: isSelected ? Colors.white : const Color(0xFFAAAAAA),
                    fontSize: 13,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildNumber(CategoryField field) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLabel(field),
        TextFormField(
          initialValue: widget.formValues[field.name]?.toString(),
          keyboardType: TextInputType.number,
          style: const TextStyle(color: Color(0xFFE0E0E0), fontSize: 14),
          decoration: InputDecoration(
            hintText: field.min != null && field.max != null
                ? '${field.min} - ${field.max}'
                : 'Kiriting',
            hintStyle: TextStyle(color: Colors.grey[600], fontSize: 14),
            filled: true,
            fillColor: const Color(0xFF1E1E2E),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF2D2D3F)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF2D2D3F)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF6C63FF), width: 1.5),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
          onChanged: (val) => widget.onChanged(field.name, num.tryParse(val) ?? val),
          validator: field.required
              ? (val) => (val == null || val.isEmpty) ? '${field.label} majburiy' : null
              : null,
        ),
      ],
    );
  }

  Widget _buildText(CategoryField field) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildLabel(field),
        TextFormField(
          initialValue: widget.formValues[field.name]?.toString(),
          style: const TextStyle(color: Color(0xFFE0E0E0), fontSize: 14),
          decoration: InputDecoration(
            hintText: 'Kiriting',
            hintStyle: TextStyle(color: Colors.grey[600], fontSize: 14),
            filled: true,
            fillColor: const Color(0xFF1E1E2E),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF2D2D3F)),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF2D2D3F)),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: Color(0xFF6C63FF), width: 1.5),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
          onChanged: (val) => widget.onChanged(field.name, val),
          validator: field.required
              ? (val) => (val == null || val.isEmpty) ? '${field.label} majburiy' : null
              : null,
        ),
      ],
    );
  }
}
