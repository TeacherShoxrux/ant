import 'package:flutter/material.dart';
import 'screens/add_product_screen.dart';

void main() {
  runApp(const XwaveApp());
}

class XwaveApp extends StatelessWidget {
  const XwaveApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Xwave',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF121218),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF6C63FF),
          surface: Color(0xFF16161F),
        ),
      ),
      home: const AddProductScreen(),
    );
  }
}
