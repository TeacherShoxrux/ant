import '../models/category_model.dart';

final List<Category> appCategories = [
  Category.fromJson({
    "id": 10,
    "name": "Transport",
    "parentId": null,
    "children": [
      {"id": 11, "name": "Yengil avtomobillar", "parentId": 10, "children": null, "fields": []},
      {"id": 12, "name": "Yuk avtomobillari", "parentId": 10, "children": null, "fields": []},
      {"id": 13, "name": "Maxsus texnika", "parentId": 10, "children": null, "fields": []},
      {"id": 14, "name": "Mototransport", "parentId": 10, "children": null, "fields": []}
    ],
    "fields": [
      {"max": 2024, "min": 1990, "name": "yili", "type": "number", "label": "Ishlab chiqarilgan yili", "required": true},
      {"name": "holati", "type": "select", "label": "Holati", "options": ["Yangi", "Ishlatilgan"], "required": true},
      {"name": "yurgan_yoli", "type": "number", "label": "Yurgan yo'li / Ish vaqti", "required": true},
      {"name": "yoqilgi", "type": "select", "label": "Yoqilg'i / Quvvat turi", "options": ["Benzin", "Gaz", "Dizel", "Elektro", "Gibrid"], "required": true},
      {"name": "uzatmalar_qutisi", "type": "select", "label": "Uzatmalar qutisi", "options": ["Mexanika", "Avtomat", "Variator", "Robot"], "required": true},
      {"name": "rangi", "type": "select", "label": "Rangi", "options": ["Oq", "Qora", "Seriy", "Qizil"], "required": true}
    ]
  }),
  Category.fromJson({
    "id": 15,
    "name": "Elektronika",
    "parentId": null,
    "children": [
      {
        "id": 16, "name": "Telefonlar", "parentId": 15, "children": null,
        "fields": [
          {"name": "xotira_rom", "type": "select", "label": "Xotira (ROM)", "options": ["32GB", "64GB", "128GB", "256GB", "512GB", "1TB"], "required": true},
          {"name": "ekran_olchami", "type": "number", "label": "Ekran o'lchami (Dyum)", "required": true}
        ]
      },
      {
        "id": 17, "name": "Kompyuterlar va noutbuklar", "parentId": 15, "children": null,
        "fields": [
          {"name": "ram", "type": "select", "label": "Tezkor xotira (RAM)", "options": ["4GB", "8GB", "16GB", "32GB", "64GB"], "required": true},
          {"name": "xotira_rom", "type": "select", "label": "Xotira (ROM)", "options": ["128GB", "256GB", "512GB", "1TB", "2TB"], "required": true}
        ]
      },
      {
        "id": 18, "name": "Maishiy texnika", "parentId": 15, "children": null,
        "fields": [
          {"name": "kafolati", "type": "select", "label": "Kafolati", "options": ["Bor (rasmiy)", "Bor (do'kon)", "Yo'q"], "required": false}
        ]
      },
      {
        "id": 19, "name": "TV, video va audio jihozlar", "parentId": 15, "children": null,
        "fields": [
          {"name": "ekran_olchami", "type": "number", "label": "Ekran o'lchami (TV uchun)", "required": false},
          {"name": "kafolati", "type": "select", "label": "Kafolati", "options": ["Bor (rasmiy)", "Bor (do'kon)", "Yo'q"], "required": false}
        ]
      },
      {
        "id": 20, "name": "O'yin konsollari va videoo'yinlar", "parentId": 15, "children": null,
        "fields": [
          {"name": "xotira_rom", "type": "select", "label": "Xotira (ROM)", "options": ["500GB", "825GB", "1TB", "2TB"], "required": false}
        ]
      },
      {"id": 21, "name": "Foto va video kameralar", "parentId": 15, "children": null, "fields": []}
    ],
    "fields": [
      {"name": "holati", "type": "select", "label": "Holati", "options": ["Yangi", "Ishlatilgan (Ideal)", "Ishlatilgan (Yaxshi)"], "required": true},
      {"name": "brendi", "type": "select", "label": "Brendi", "options": ["Apple", "Samsung", "LG", "HP", "Sony", "Boshqa"], "required": true}
    ]
  }),
  Category.fromJson({
    "id": 22,
    "name": "Ko'chmas mulk",
    "parentId": null,
    "children": [
      {
        "id": 23, "name": "Kvartiralar (Sotuv/Ijara)", "parentId": 22, "children": null,
        "fields": [
          {"name": "xonalar", "type": "select", "label": "Xonalar soni", "options": ["1", "2", "3", "4", "5+"], "required": true},
          {"name": "maydoni", "type": "number", "label": "Maydoni (m2)", "required": true},
          {"name": "qavat", "type": "number", "label": "Qavat", "required": true},
          {"name": "remont", "type": "select", "label": "Remont", "options": ["Yevro", "O'rtacha", "Ta'mir talab"], "required": false}
        ]
      },
      {
        "id": 24, "name": "Hovli", "parentId": 22, "children": null,
        "fields": [
          {"name": "yer_maydoni", "type": "number", "label": "Yer maydoni (Sotix)", "required": true}
        ]
      },
      {"id": 25, "name": "Tijorat ko'chmas mulki (Ofis, do'kon, ombor)", "parentId": 22, "children": null, "fields": []},
      {"id": 26, "name": "Avtoturargoh va garajlar", "parentId": 22, "children": null, "fields": []}
    ],
    "fields": []
  }),
  Category.fromJson({
    "id": 27,
    "name": "Ish",
    "parentId": null,
    "children": [
      {"id": 28, "name": "IT va internet", "parentId": 27, "children": null, "fields": []},
      {"id": 29, "name": "Sotuv va marketing", "parentId": 27, "children": null, "fields": []},
      {"id": 30, "name": "Qurilish va ta'mirlash", "parentId": 27, "children": null, "fields": []},
      {"id": 31, "name": "Transport va logistika", "parentId": 27, "children": null, "fields": []},
      {"id": 32, "name": "Umumiy ovqatlanish va turizm", "parentId": 27, "children": null, "fields": []},
      {"id": 33, "name": "Uydagi ish (Freelance)", "parentId": 27, "children": null, "fields": []}
    ],
    "fields": [
      {"name": "maosh_gacha", "type": "number", "label": "Maosh (gacha)", "required": false},
      {"name": "bandlik_turi", "type": "select", "label": "Bandlik turi", "options": ["To'liq", "Yarim stavka", "Masofaviy", "Amaliyot"], "required": true},
      {"name": "ish_tajribasi", "type": "select", "label": "Ish tajribasi", "options": ["Tajriba shart emas", "1-3 yil", "3-5 yil", "5+"], "required": true},
      {"name": "malumoti", "type": "select", "label": "Ma'lumoti", "options": ["Oliy", "O'rta-maxsus", "O'rta"], "required": false},
      {"name": "aloqa_ism", "type": "text", "label": "Aloqa uchun ism", "required": true},
      {"name": "telefon_raqami", "type": "text", "label": "Telefon raqami", "required": true}
    ]
  }),
  Category.fromJson({
    "id": 34,
    "name": "Uy va bog'",
    "parentId": null,
    "children": [
      {
        "id": 35, "name": "Mebel (Divan, shkaf, stol-stul)", "parentId": 34, "children": null,
        "fields": [
          {"name": "materiali", "type": "select", "label": "Materiali", "options": ["Yog'och", "MDF", "Plastik", "Shisha", "Metall", "Boshqa"], "required": false},
          {"name": "olchamlari", "type": "text", "label": "O'lchamlari (Masalan: 200x150x80 sm)", "required": false},
          {"name": "yetkazib_berish", "type": "select", "label": "Yetkazib berish", "options": ["Bor", "Yo'q", "Kelishiladi"], "required": false}
        ]
      },
      {"id": 36, "name": "Idish-tovoq va oshxona anjomlari", "parentId": 34, "children": null, "fields": []},
      {
        "id": 37, "name": "Qurilish va ta'mirlash mollari", "parentId": 34, "children": null,
        "fields": [
          {"name": "olchamlari", "type": "text", "label": "O'lchamlari", "required": false},
          {"name": "yetkazib_berish", "type": "select", "label": "Yetkazib berish", "options": ["Bor", "Yo'q", "Kelishiladi"], "required": false}
        ]
      },
      {"id": 38, "name": "Bog'dorchilik inventarlari", "parentId": 34, "children": null, "fields": []},
      {
        "id": 39, "name": "Interyer va dekor", "parentId": 34, "children": null,
        "fields": [
          {"name": "materiali", "type": "select", "label": "Materiali", "options": ["Yog'och", "MDF", "Plastik", "Shisha", "Metall", "Boshqa"], "required": false}
        ]
      }
    ],
    "fields": [
      {"name": "holati", "type": "select", "label": "Holati", "options": ["Yangi", "Ishlatilgan"], "required": true},
      {"name": "rangi", "type": "select", "label": "Rangi", "options": ["Jigarrang", "Oq", "Qora", "Kulrang", "Boshqa"], "required": false}
    ]
  }),
  Category.fromJson({
    "id": 40,
    "name": "Shaxsiy buyumlar",
    "parentId": null,
    "children": [
      {
        "id": 41, "name": "Kiyim-kechak va poyabzal (Erkaklar/Ayollar)", "parentId": 40, "children": null,
        "fields": [
          {"name": "jinsi", "type": "select", "label": "Jinsi", "options": ["Erkaklar uchun", "Ayollar uchun", "Unisex"], "required": true},
          {"name": "olchami", "type": "select", "label": "O'lchami", "options": ["XS", "S", "M", "L", "XL", "36", "37", "38", "39", "40", "41", "42", "43", "44", "Boshqa"], "required": true}
        ]
      },
      {"id": 42, "name": "Bolalar dunyosi (O'yinchoqlar, kiyimlar, aravachalar)", "parentId": 40, "children": null, "fields": []},
      {
        "id": 43, "name": "Soatlar va zargarlik buyumlari", "parentId": 40, "children": null,
        "fields": [
          {"name": "turi", "type": "select", "label": "Buyum turi", "options": ["Uzuk", "Zanjir", "Soat", "Bilaguzuk", "Boshqa"], "required": false}
        ]
      },
      {
        "id": 44, "name": "Go'zallik va salomatlik (Parfyumeriya, kosmetika)", "parentId": 40, "children": null,
        "fields": [
          {"name": "turi", "type": "select", "label": "Mahsulot turi", "options": ["Parfyum", "Krem", "Kosmetika", "Soch parvarishi", "Boshqa"], "required": false}
        ]
      }
    ],
    "fields": [
      {"name": "holati", "type": "select", "label": "Holati", "options": ["Yangi", "Ishlatilgan (Yaxshi)", "Ishlatilgan (O'rtacha)"], "required": true},
      {"name": "brendi", "type": "select", "label": "Brendi", "options": ["Zara", "Adidas", "Rolex", "Chanel", "Boshqa"], "required": false},
      {"name": "rangi", "type": "select", "label": "Rangi", "options": ["Qora", "Oq", "Qizil", "Ko'k", "Boshqa"], "required": false}
    ]
  }),
  Category.fromJson({
    "id": 45,
    "name": "Xizmatlar",
    "parentId": null,
    "children": [
      {
        "id": 46, "name": "Ta'lim va repetitorlik", "parentId": 45, "children": null,
        "fields": [
          {"name": "otkazish_joyi", "type": "select", "label": "O'tkazish joyi", "options": ["Onlayn", "Borib ishlash", "O'z joyida"], "required": false}
        ]
      },
      {
        "id": 47, "name": "Tashish va yuk tashish xizmati", "parentId": 45, "children": null,
        "fields": [
          {"name": "transport_turi", "type": "select", "label": "Transport turi", "options": ["Labo", "Gazel", "Fura", "Manipulyator", "Boshqa"], "required": false}
        ]
      },
      {
        "id": 48, "name": "Tibbiy xizmatlar", "parentId": 45, "children": null,
        "fields": [
          {"name": "otkazish_joyi", "type": "select", "label": "O'tkazish joyi", "options": ["Onlayn", "Borib ishlash", "O'z joyida"], "required": false}
        ]
      },
      {
        "id": 49, "name": "Tantanalar va tadbirlar", "parentId": 45, "children": null,
        "fields": [
          {"name": "xizmat_turi", "type": "multi-select", "label": "Xizmat turi", "options": ["Boshlovchi", "Foto", "Video", "Bezatish", "Boshqa"], "required": false}
        ]
      },
      {
        "id": 50, "name": "Maishiy texnika ta'mirlash", "parentId": 45, "children": null,
        "fields": [
          {"name": "kafolat", "type": "select", "label": "Kafolat", "options": ["Bor", "Yo'q"], "required": false}
        ]
      }
    ],
    "fields": [
      {"name": "tolov_turi", "type": "select", "label": "To'lov turi", "options": ["Soatbay", "Kunbay", "Loyiha uchun", "Kelishiladi"], "required": true}
    ]
  }),
  Category.fromJson({
    "id": 51,
    "name": "Hayvonlar",
    "parentId": null,
    "children": [
      {
        "id": 52, "name": "Uy hayvonlari (Kuchuk, mushuk)", "parentId": 51, "children": null,
        "fields": [
          {"name": "turi_zoti", "type": "select", "label": "Turi / Zoti", "options": ["Kuchuk", "Mushuk", "Qush", "Baliq", "Kemiruvchi", "Boshqa"], "required": true},
          {"name": "yoshi", "type": "text", "label": "Yoshi (Masalan: 2 oylik, 1 yosh)", "required": true},
          {"name": "jinsi", "type": "select", "label": "Jinsi", "options": ["Erkak", "Urg'ochi"], "required": true},
          {"name": "vaksina", "type": "select", "label": "Vaksina / Emlash", "options": ["Emlangan", "Emlanmagan"], "required": false}
        ]
      },
      {
        "id": 53, "name": "Qishloq xo'jaligi hayvonlari (Chorva)", "parentId": 51, "children": null,
        "fields": [
          {"name": "turi_zoti", "type": "select", "label": "Turi / Zoti", "options": ["Qoramol (Sigir, Buqa)", "Qo'y / Qo'chqor", "Echki", "Ot", "Parranda", "Boshqa"], "required": true},
          {"name": "yoshi", "type": "text", "label": "Yoshi (Masalan: 6 oylik, 2 yosh)", "required": true},
          {"name": "jinsi", "type": "select", "label": "Jinsi", "options": ["Erkak", "Urg'ochi"], "required": true},
          {"name": "vaksina", "type": "select", "label": "Vaksina / Emlash", "options": ["Emlangan", "Emlanmagan"], "required": false}
        ]
      },
      {
        "id": 54, "name": "Hayvonlar uchun ozuqa va aksessuarlar", "parentId": 51, "children": null,
        "fields": [
          {"name": "mahsulot_turi", "type": "select", "label": "Mahsulot turi", "options": ["Ovqat / Ozuqa", "Shampun / Gigiyena", "Kletka / Uycha", "O'yinchoq", "Boshqa"], "required": true}
        ]
      }
    ],
    "fields": []
  }),
];
